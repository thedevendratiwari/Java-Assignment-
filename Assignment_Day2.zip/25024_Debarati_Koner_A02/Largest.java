import java.util.*;

public class Largest {
    static int findLargest(int a, int b) {
        if (a > b) {
            return a;
        } else {
            return b;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int a = sc.nextInt();
        int b = sc.nextInt();

        int largest = findLargest(a, b);

        System.out.println("Largest: " + largest);

        sc.close();
    }
}