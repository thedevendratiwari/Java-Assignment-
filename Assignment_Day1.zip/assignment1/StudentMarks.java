package assignment1;

public class StudentMarks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		    int sub1 = 80;
	        int sub2 = 75;
	        int sub3 = 90;

	        int total = sub1 + sub2 + sub3;
	        double average = total / 3.0;

	        System.out.println("Subject 1 = " + sub1);
	        System.out.println("Subject 2 = " + sub2);
	        System.out.println("Subject 3 = " + sub3);
	        System.out.println("Total Marks = " + total);
	        System.out.println("Average Marks = " + average);
	}

}
