package assignment1;

public class StudentResult {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int marks = 65;

        if (marks >= 40) {
            System.out.println("Student has Passed");
        } else {
            System.out.println("Student has Failed");
        }
	}

}
