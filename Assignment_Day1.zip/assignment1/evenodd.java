package assignment1;

public class evenodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int number = 7;

        if (number % 2 == 0) {
            System.out.println("Number is Even");
        } else {
            System.out.println("Number is Odd");
        }
	}

}
