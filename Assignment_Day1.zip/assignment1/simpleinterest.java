package assignment1;

public class simpleinterest {

	public static void main(String[] args) {
		double principal = 10000;
        double rate = 5;
        double time = 2;

        double interest = (principal * rate * time) / 100;
        double amount = principal + interest;

        System.out.println("Principal = " + principal);
        System.out.println("Simple Interest = " + interest);
        System.out.println("Total Amount = " + amount);

	}

}
