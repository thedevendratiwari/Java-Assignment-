package assignment1;

public class ArithmeticOperations {

	public static void main(String[] args) {
		int a = 20;
		int b = 30;
		System.out.println("addition = "+(a+b));
		System.out.println("subtraction = "+(a-b));
		System.out.println("multipication = "+(a*b));
		System.out.println("division = "+(a/b));
		System.out.println("remainder = "+(a%b));

	}

}
