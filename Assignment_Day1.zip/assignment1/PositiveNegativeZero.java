package assignment1;

public class PositiveNegativeZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int number = -5;

        if (number > 0) {
            System.out.println("Number is Positive");
        } else if (number < 0) {
            System.out.println("Number is Negative");
        } else {
            System.out.println("Number is Zero");
        }
	}

}
