package assignment1;

public class LargestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a = 25;
        int b = 40;

        if (a > b) {
            System.out.println(a + " is larger");
        } else if (b > a) {
            System.out.println(b + " is larger");
        } else {
            System.out.println("Both numbers are equal");
        }
	}

}
