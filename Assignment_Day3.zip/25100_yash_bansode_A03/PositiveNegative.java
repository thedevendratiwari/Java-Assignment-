package ass3;

import java.util.Scanner;

public class PositiveNegative {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number: ");
        int n = sc.nextInt();

        int[] arr = new int[n];
        int zeros = 0;

        System.out.println("Enter num:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < n; i++) {
            if (arr[i] > 0) {
                System.out.println("Positive: " + arr[i]);
            } else if (arr[i] < 0) {
                System.out.println("Negative: " + arr[i]);
            } else {
                zeros++;
            }
        }

        System.out.println("Zero values: " + zeros);

        sc.close();
    }
}