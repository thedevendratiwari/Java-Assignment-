package assignment4;
import java.util.*;

class EmployeeDetails{
	int emp_id;
	String name;
	double salary;
	public void read() {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter employee id: ");
		emp_id=sc.nextInt();
		System.out.print("Enter name of the employeeeee: ");
		name=sc.next();
		System.out.print("Enter the salary of employee: ");
		salary=sc.nextDouble();
	}
	public void display() {
		System.out.println("Employee id: "+emp_id);
		System.out.println("Employee name: "+name);
		System.out.println("Employee salary: "+salary);
	}
	public void calculateSalary() {
		double updated_salary=salary+(salary*20/100)+(salary*10/100);
		System.out.println("Salary after adding HRA and DA: "+updated_salary);
	}
}
public class Employee {

	public static void main(String[] args) {
		EmployeeDetails emp=new EmployeeDetails();
		emp.read();
		emp.display();
		emp.calculateSalary();
	}

}
