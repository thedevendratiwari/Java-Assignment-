package assignment4;
import java.util.*;

class CalculateBill{
	int number;
	String name;
	double units;
	
	public void read() {
		Scanner sc=new Scanner(System.in);
		number=sc.nextInt();
		name=sc.next();
		units=sc.nextDouble();
	}
	public void display() {
		System.out.println("Consumer number: "+number);
		System.out.println("Consumer name: "+name);
		System.out.println("Units consumed: "+units);
	}
	
	public void calculateBill() {
		if (units <= 100){
			units = units * 3;
		}
		else if (units <= 200) {
			units =(units*3)+((units-100)*5);
		}
		else {
			units = (units*3)+((units-100)*5)+((units-200)*8);
		}
		System.out.println(units);
	}
}

public class ElectricityBill {

	public static void main(String[] args) {
		CalculateBill cb = new CalculateBill();
		cb.read();
		cb.display();
		cb.calculateBill();
		
		
	}

}
