package assignment4;
import java.util.*;
class AccountHandling{
	int acc_number;
	String name;
	double balance;
	public void read() {
		Scanner sc = new Scanner(System.in);
		acc_number = sc.nextInt();
		name = sc.next();
		balance = sc.nextDouble();
	}
	public void display() {
		System.out.println("Acc. number: " + acc_number);
		System.out.println("Acc holder name: " + name);
		System.out.println("Acc. balance: " + balance);
	}
	public String checkCategory() {
		String res;
		if (balance >= 100000)
		{
			res = "Premium";
		}
		else if (balance >= 25000 && balance < 100000)
		{
			res = "Standard";
		}
		else
		{
			res = "Basic";
		}
		return res;
	}
	
}
public class BankAccount {
	
	public static void main(String args[]) {
		AccountHandling ah = new AccountHandling();
		ah.read();
		ah.display();
		String var1 = ah.checkCategory();
		System.out.println("Account category: " + var1);
	}

}
