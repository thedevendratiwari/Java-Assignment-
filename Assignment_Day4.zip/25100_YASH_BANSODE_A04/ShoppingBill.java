package assignment4;
import java.util.*;

class OnlineShopping{
	int orderID;
	String cust_name;
	double amount;
	
	public void read() {
	Scanner sc = new Scanner(System.in);
	orderID = sc.nextInt();
	cust_name = sc.next();
	amount = sc.nextDouble();
	}
	
	public void display() {
		System.out.println("OrderID: " + orderID);
		System.out.println("Customer name: " + cust_name);
		System.out.println("Amount: " + amount);
	}
	
	public void calculateDiscount() {
		if(amount>=1000) {
			amount = (amount - (amount * 5/100));
		}
		else if(amount>=5000) {
			amount = (amount - (amount * 10/100));
		}
		else if(amount>=10000) {
			amount = (amount - (amount * 15/100));
		}
		else {
			System.out.println("No discount");
		}
		System.out.println(amount);
	}
}

public class ShoppingBill {

	public static void main(String[] args) {
		OnlineShopping o = new OnlineShopping();
		o.read();
		o.display();
		o.calculateDiscount();
	}

}
