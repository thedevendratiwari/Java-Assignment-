package assignment4;
import java.util.Scanner;

class Student {
	int st_id;
	String name;
	int marks;
	public void read() {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter id of student: ");
		st_id=sc.nextInt();
		System.out.print("Enter name of student: ");
		name=sc.next();
		System.out.print("Enter marks of student: ");
		marks=sc.nextInt();
		
//		sc.close();
	}
	public void display() {
		System.out.println("Student id "+st_id);
		System.out.println("Student name "+name);
		System.out.println("Student marks "+marks);
	}
	public int findResult() {
		if(marks>=50) {
			return 1;
		}
		else {
			return 0;
		}
	}
}

public class StudentResultMain {

	public static void main(String[] args) {
		Student res=new Student();
		res.read();
		res.display();
		int a=res.findResult();
		if(a==0) {
			System.out.println("Fail");
		}
		else {
			System.out.println("Pass");
		}
	}

}
